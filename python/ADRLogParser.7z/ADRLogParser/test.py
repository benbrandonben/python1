from src.ADRLog import ADRBIN

binfile = "/home/ling/workspace/ADRLogParser/Sample/AEB_log_raw"
adr = ADRBIN(binfile)
for key in adr.head_info.keys():
    print(key, adr.head_info[key])
adr.to_blf()
adr.to_asc()
