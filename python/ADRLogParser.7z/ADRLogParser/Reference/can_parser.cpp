#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <adr_spi_msg.h>
#include <string>

using namespace std;

int main(int argc, char **argv) {
    uint8_t buf[512] = {0};
    CanHeadInfo *head = NULL;

    if( argc < 2 ) {
        printf("Error: please enter can data\n");
        return -1;
    }

    int header_size = sizeof(CanHeadInfo);
    int can_data_size = sizeof(CanData);

    int fd = open(argv[1], O_RDONLY);
    if( fd == -1 ) {
        printf("Fail to open %s\n", argv[1]);
    }

    read(fd, buf, header_size);
    head = (CanHeadInfo *)buf;

    printf("ECUHwVersion_Buffer: [%s]\n", string((char *)(head->ECUHwVersion_Buffer), sizeof(head->ECUHwVersion_Buffer)).c_str());
    printf("DcmDID_ECUSN_a: [%s]\n", string((char *)(head->DcmDID_ECUSN_a), sizeof(head->DcmDID_ECUSN_a)).c_str());
    printf("VINDataIdentifier: [%s]\n", string((char *)(head->VINDataIdentifier), sizeof(head->VINDataIdentifier)).c_str());
    printf("DID_CA_Fingerprint_a: [%s]\n",string((char *)( head->DID_CA_Fingerprint_a), sizeof(head->DID_CA_Fingerprint_a)).c_str());
    printf("ECUSwVersion_Buffer: [%s]\n", string((char *)(head->ECUSwVersion_Buffer), sizeof(head->ECUSwVersion_Buffer)).c_str());
    printf("ECU_Hardware_Number: [%s]\n", string((char *)(head->ECU_Hardware_Number), sizeof(head->ECU_Hardware_Number)).c_str());
    printf("ECUSoftware_Number: [%s]\n", string((char *)(head->ECUSoftware_Number), sizeof(head->ECUSoftware_Number)).c_str());
    printf("\n");

    int num = 0;
    CanData *p = NULL;
    int i = 0;
    while(1) {
        num =  read(fd, buf, can_data_size);
        if( num < can_data_size ) break;
        p = (CanData *)buf;
        printf("timestamp: [%lu]\n", p->timestamp);
        printf("can_id: [%x]\n", p->can_id);
        printf("channel: [%d]\n", p->channel);
        printf("data_length: [%d]\n", p->data_length);
        printf("can data[%d]: ", i++);
        for(int i=0; i<p->data_length; i++) {
            printf("%02X ", p->can_data[i]);
        }
        printf("\n");
        printf("\n");
    }
}


