#ifndef ADR_SPI_MSG_H_
#define ADR_SPI_MSG_H_

#pragma pack(1)

//由adr触发，发送给MCU；type id :0x0906, sub id : 0x0002
typedef struct {
  uint8_t controller_code;
  uint8_t eid;
  uint8_t event_start_end_identify;
  uint8_t event_amount;
  uint16_t event_code;
  uint8_t year;
  uint8_t month;
  uint8_t day;
  uint8_t hour;
  uint8_t minute;
  uint8_t second;
} UploadReqBody;

typedef struct {
  uint32_t id;
  UploadReqBody payload;
} UploadReq;

// type id :0x0806, sub id : 0x0000
typedef struct
{
  unsigned char ECUHwVersion_Buffer[15];  // ECU硬件版本号 F191
  unsigned char DcmDID_ECUSN_a[13];  // F194
  unsigned char VINDataIdentifier[17];  // F190
  unsigned char DID_CA_Fingerprint_a[7];  // 应用程序刷写指纹信息 F184
  unsigned char ECUSwVersion_Buffer[15];  // ECU软件版本号 F189
  unsigned char ECU_Hardware_Number[21];  // ECU硬件件号 F187
  unsigned char ECUSoftware_Number[20];  // ECU软件件号 F188
} CanHeadInfo;

// type id :0x0605, sub id : 0x0000
typedef struct
{
  uint32_t event;
  uint64_t timestamp;
} TriggerCMD;

// type id :0x0606, sub id : 0x0000

typedef struct
{
  uint64_t timestamp;  // 1970-1-1 0:0到当前的微秒数
  uint16_t can_id;
  uint8_t channel;  // 报文通道号：1-1R1V，2-Reserved，3-ADAS ACAN, 4-Reserved
  uint8_t data_length;
  unsigned char can_data[64];
} CanData;

#pragma pack()

#define MCU_WORK

#endif  // ADR_SPI_MSG_H_